import sympy.vector as vec
from sympy.vector import CoordSys3D

GCS: CoordSys3D = vec.CoordSys3D('GCS')

name = "volume_grating"